﻿// Археолог нашел N артефактов. Известны веса (сi) и объемы (di) артефактов. Нужно
//выбрать такое подмножество найденных вещей, чтобы суммарный их вес не превысил B кг, но
//был наиболее близок к B, а количество взятых артефактов было как можно больше.Известно,
//что решение единственно.Укажите порядковые номера вещей, которые надо взять.Исходные
//данные находятся в текстовом файле, в первой строке указаны N и B, а во второй строке значения весов(в кг), 
// в третьей объемы находок(в куб.см).
//Вывести так же суммарный вес и суммарный объем результата.

#include <iostream>
#include <fstream> 
#include <vector>
#include <sstream>
#include <algorithm>
using namespace std;
//восстановление
void vosst(const vector<vector<int>>& dp,const vector<int>& ves, vector<int>& vol,int k,int b,int& volume,int& finves) {
	if (k == 0 || b == 0) //если не осталось предметов
		return;
	if (dp[k][b] == dp[k - 1][b]) {
		vosst(dp, ves,vol, k - 1, b,volume,finves);//пропуск
	}
	else {
		cout << "предмет " << k << " весом " << ves[k] << endl;
		volume += vol[k];
		finves += ves[k];
		vosst(dp, ves,vol, k - 1, b - ves[k],volume,finves);
	}
}
int main() {
	setlocale(LC_ALL, "RU");
	int n, b;
	string s = "C:\\Users\\kseNari\\Desktop\\lab 13\\bag.txt";
	ifstream file(s);
	if (!file.is_open()) {
		cout << "Не удалось открыть файл";
		return 1;
	}
	file >> n >> b;
	file.ignore(); //пропуск остатка строки
	vector<int> ves(n+1,0); //веса индексация с 1
	vector<int> vol(n+1,0); //объемы 
	//вектор со значением веса предметов
	string line;
	if (getline(file, line)) {
		istringstream strk(line);
		for (int i = 0; i <= n && strk>>ves[i]; i++) {
		}
	}
	//вектор со значением объемов предметов
	if (getline(file, line)) {
		istringstream strk(line);
		for (int i = 0; i <= n && strk >> vol[i]; i++) {
		}
	}

	cout << "Доступные веса предметов:" << endl;
	for (int i = 1; i <= n; i++) {
		cout << ves[i] << endl;
	}

	vector<vector<int>> dp(n + 1, vector<int>(b + 1, 0));
	for (int k = 1; k <= n; k++) { //номер предмета
		for (int i = 0; i <= b; i++) { //вместимость
			if (i >= ves[k])
				dp[k][i] = max(dp[k - 1][i], dp[k - 1][i - ves[k]]+1);//макс не берем или берем
			else {
				dp[k][i] = dp[k - 1][i];
			}
		}
	}
	int volume = 0;
	int finves = 0;
	cout << "Максимальное количество: " << dp[n][b] << endl;
	cout << "Были включены предметы: " << endl;
	vosst(dp, ves,vol, n, b,volume,finves);
	cout << "Вес предметов: " <<finves<< endl;
	cout << "Объем предметов: " <<volume << endl;

return 0;
}