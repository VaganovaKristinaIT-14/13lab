﻿#include <iostream>
#include <vector>
using namespace std;

double knum(int n, int k) {
	//dp[i][z]- кол во чисел длины i с z нулями подряд 
	vector<vector<double>> dp(n + 1, vector<double>(4, 0));
	//базовый случай,длина 1
	dp[1][0] = k - 1; //первый разряд не 0
	dp[1][1] = 1; //0
	for (int i = 2; i <= n; i++) {
		for (int z = 0; z <= 3; z++) {
			dp[i][0] += dp[i - 1][z] * (k - 1);//если цифра не 0, можно взять любую из к-1 цифр
			if (z > 0) { //есть ли z-1 подряд нулей?
				dp[i][z] += dp[i - 1][z - 1];//если 0 - +последовательность нулец
			}
		}
	}
	double result = 0;
	for (int z = 0; z <= 3; z++) {
		result += dp[n][z];
	}
	return result;
}

int main() {
	setlocale(LC_ALL, "RU");
	int k, n;
	cout << "Введите длинну числа n" << endl;
	cin >> n;
	cout << "Введите основание системы счисления" << endl;
	cin >> k;
	double result = knum(n, k);
	cout << "Количество чисел: " << result;
	return 0;

}