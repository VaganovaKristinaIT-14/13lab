﻿#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    setlocale(LC_ALL, "RU");
    string s = "C:\\Users\\kseNari\\Desktop\\lab 13\\king.txt";
    ifstream file(s);
    if (!file.is_open()) {
        cout<< "не удалось открыть файл" << endl;
        return 1;
    }

    int N;
    file >> N; 

    //векторы: доска,максзнач,путь
    vector<vector<int>> board(N, vector<int>(N, 0));
    vector<vector<int>> dp(N, vector<int>(N, 0));
    vector<vector<char>> path(N, vector<char>(N, ' '));

    //заполняем доску
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            file >> board[i][j];
        }
    }

    //начало пути
    dp[N - 1][N - 1] = board[N - 1][N - 1];

    // Заполняем dp снизу вверх и справа налево
    for (int i = N - 1; i >= 0; i--) {//вверх
        for (int j = N - 1; j >= 0; j--) {//слева направо
            if (i < N - 1) { // Движение вверх 
                if (dp[i][j] < dp[i + 1][j] + board[i][j]) {//если снизу больше
                    dp[i][j] = dp[i + 1][j] + board[i][j];
                    path[i][j] = 'U';
                }
            }
            if (j < N - 1) { // Движение влево
                if (dp[i][j] < dp[i][j + 1] + board[i][j]) { 
                    dp[i][j] = dp[i][j + 1] + board[i][j];
                    path[i][j] = 'L';
                }
            }
        }
    }
    string out = "C:\\Users\\kseNari\\Desktop\\lab 13\\kingout.txt";
    ofstream file1(out);
    file1 << dp[0][0] << endl;

    // Восстановление пути
    string route = "";
    int x = 0, y = 0;
    while (x != N - 1 || y != N - 1) {
        route += path[x][y];
        if (path[x][y] == 'U') {
            x++;//вниз
        }
        else {
            y++;//вправо
        }
    }
    reverse(route.begin(), route.end());
    file1<< route << endl;
    cout << "Данные записаны в файл kingout.txt";

    return 0;
}
